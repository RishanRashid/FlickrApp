//
//  SearchTermsTableViewCell.swift
//  TheNewFlickr
//
//  Created by Rishan on 20/10/2021.
//
import UIKit

class SearchTermsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
